const http = require('http');
const mysql = require('mysql');
const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const bodyParser = require('body-parser');

const hostname = '127.0.0.1';
const httpPort = 3000;
const expressPort = 8080;

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello World\n');
});

server.listen(httpPort, hostname, () => {
  console.log(`HTTP server running at http://${hostname}:${httpPort}/`);
});

var conn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Zaya!9884",
  database: "myboard",
});

conn.connect(err => {
  if (err) throw err;
  console.log('MySQL connected...');
});

const app = express();

const db = require('node-mysql/lib/db');app.use(bodyParser.urlencoded
({extended:true}));
app.set('view engine', 'ejs');

let mydb; // 전역 변수로 선언

app.get('/book', (req, res) => {
  res.send('도서 목록 관련 페이지입니다.');
});

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.get('/list', function(req, res){
    mydb.collection('post').find().toArray(function(err, result){
      console.log(result);
      res.render('list.ejs', {data : result });
    })
});


// res.sendFile(__dirname + '/list.html');
// res.render('list.ejs', {data : result });


app.get('/enter', function (req, res){
  res.render('enter.ejs');
});
  //res.sendFile(__dirname + '/enter.html');


app.post('/save', function(req, res){
   console.log(req.body.title);
   console.log(req.body.content);
   console.log(req.body.someDate);
  if (!mydb) {
    res.status(500).send('MongoDB not connected');
    return;
  }

  // MongoDB
  mydb.collection('post').insertOne({title : req.body.title, content : req.body.content, date : req.body.someDate}).then(result => {
      console.log(result);
      console.log('데이터 추가 성공');
      res.send('데이터 추가 성공');
    })
    .catch(err => {
      console.error(err);
      res.status(500).send('Error adding data');
    });

  // MySQL
  // let sql = "INSERT INTO post (title, content, created) VALUES (?, ?, NOW())";
  // let params = [req.body.title, req.body.content];
  // conn.query(sql, params, (err, result) => {
  //   if (err) throw err;
  //   console.log('데이터 추가 성공');
  // });
});

// MongoDB 연결
const mongoUrl = 'mongodb+srv://ankhzya620:Zaya9884@cluster0.ne8kzz1.mongodb.net/';
MongoClient.connect(mongoUrl, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(client => {
    console.log("MongoDB connected...");
    mydb = client.db('myboard');

    app.listen(expressPort, () => {
      console.log(`Express server running at http://${hostname}:${expressPort}/`);
    });
  })
  .catch(err => {
    console.error(err);
  });

  //content 요청에 대한 처리루틴
  app.get('/content/:id', function(req, res){
    console.log(req.params.id);
    req.params.id = new ObjectId(req.params.id);
    mydb
      .collection("post")
      .findOne({_id : req.params.id })
      .then((result) => {
        console.log(result);
        res.render("content.ejs", { data :result });
      });
    });
    //edit 요청에 대한 처리 루틴
   app.get('/edit/:id', function (req, res){
    req.params.id = new ObjectId(req.params.id);
    mydb
      .collection("post")
      .findOne({ _id:req.params.id })
      .then((result) => {
        console.log(result);
    res.render("edit.ejs", {data :result});
   });
   });
